package com.myinterviewprep.InterviewPrepAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewPrepApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
