package com.myinterviewprep.InterviewPrepAPI.repository;

import com.myinterviewprep.InterviewPrepAPI.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task, Long> {
}
