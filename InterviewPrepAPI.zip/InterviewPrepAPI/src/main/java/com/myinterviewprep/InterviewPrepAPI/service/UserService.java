package com.myinterviewprep.InterviewPrepAPI.service;

public interface UserService {
}
