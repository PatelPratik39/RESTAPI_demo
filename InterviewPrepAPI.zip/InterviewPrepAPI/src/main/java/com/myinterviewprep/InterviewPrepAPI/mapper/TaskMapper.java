package com.myinterviewprep.InterviewPrepAPI.mapper;

import com.myinterviewprep.InterviewPrepAPI.dto.TaskDto;
import com.myinterviewprep.InterviewPrepAPI.entity.Task;

public class TaskMapper {

    //converting entity class to Dto class

    public static TaskDto taskDto(Task task){
        TaskDto taskDto = new TaskDto();
        taskDto.setId(task.getId());
        taskDto.setName(task.getName());
        taskDto.setDescription(task.getDescription());
        return taskDto;
    }

//    converting dto class to entity class
    public static Task toEntity(TaskDto taskDto){
        Task task = new Task();
        task.setName(taskDto.getName());
        task.setDescription(taskDto.getDescription());
        return task;
    }
}
