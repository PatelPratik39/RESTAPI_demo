package com.myinterviewprep.InterviewPrepAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewPrepApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterviewPrepApiApplication.class, args);
	}

}
