package com.myinterviewprep.InterviewPrepAPI.service.Impl;

import com.myinterviewprep.InterviewPrepAPI.entity.Task;
import com.myinterviewprep.InterviewPrepAPI.repository.TaskRepository;
import com.myinterviewprep.InterviewPrepAPI.service.TaskService;
import lombok.Data;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;
import org.springframework.cache.annotation.Cacheable;

@Service
@Data
public class TaskServiceImpl implements TaskService {

    private TaskRepository taskRepository;

    @Override
    @Cacheable(value = "tasks", key="#id")
    public Task getTaskById(Long id) {
        return taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Task Not Found!!!"));
    }

    @Override
    @CachePut(value = "tasks",key = "#result.id")
    public Task createTask(Task task) {
        return taskRepository.save(task);
    }

    @Override
    @CachePut(value = "tasks", key = "#result.id")
    public Task updateTask(Long id, Task taskDetails) {
       Task task = taskRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Task Not Found!!!"));
       task.setName(taskDetails.getName());
       task.setDescription(taskDetails.getDescription());
        return taskRepository.save(task);
    }

    @Override
    @CacheEvict(value = "tasks", key="#id")
    public void deleteTask(Long id) {
         taskRepository.deleteById(id);
    }
}
